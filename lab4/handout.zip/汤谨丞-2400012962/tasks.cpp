#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <spdlog/spdlog.h>
#include <iostream>
#include "Labs/4-Animation/tasks.h"
#include "IKSystem.h"
#include "CustomFunc.inl"


namespace VCX::Labs::Animation {
    void ForwardKinematics(IKSystem & ik, int StartIndex) {
        if (StartIndex == 0) {
            ik.JointGlobalRotation[0] = ik.JointLocalRotation[0];
            ik.JointGlobalPosition[0] = ik.JointLocalOffset[0];
            StartIndex                = 1;
        }
        
        for (int i = StartIndex; i < ik.JointLocalOffset.size(); i++) {
            // your code here: forward kinematics, update JointGlobalPosition and JointGlobalRotation
            ik.JointGlobalRotation[i] = ik.JointGlobalRotation[i - 1] * ik.JointLocalRotation[i];
            ik.JointGlobalPosition[i] = ik.JointGlobalPosition[i - 1] + ik.JointGlobalRotation[i - 1] * ik.JointLocalOffset[i];
        }
    }

    void InverseKinematicsCCD(IKSystem & ik, const glm::vec3 & EndPosition, int maxCCDIKIteration, float eps) {
        ForwardKinematics(ik, 0);
        // These functions will be useful: glm::normalize, glm::rotation, glm::quat * glm::quat
        for (int CCDIKIteration = 0; CCDIKIteration < maxCCDIKIteration && glm::l2Norm(ik.EndEffectorPosition() - EndPosition) > eps; CCDIKIteration++) {
            // your code here: ccd ik
            int nJoints = ik.NumJoints();
            for(int i=nJoints-2;i>=0;i--)
            {
                glm::vec3 to_end = ik.EndEffectorPosition() - ik.JointGlobalPosition[i];
                glm::vec3 to_target = EndPosition - ik.JointGlobalPosition[i];
                glm::quat delta_rotation = glm::rotation(glm::normalize(to_end), glm::normalize(to_target));
                ik.JointLocalRotation[i] = delta_rotation * ik.JointLocalRotation[i];
                ForwardKinematics(ik, i);    
            }
        }
    }

    void InverseKinematicsFABR(IKSystem & ik, const glm::vec3 & EndPosition, int maxFABRIKIteration, float eps) {
        ForwardKinematics(ik, 0);
        int nJoints = ik.NumJoints();
        std::vector<glm::vec3> backward_positions(nJoints, glm::vec3(0, 0, 0)), forward_positions(nJoints, glm::vec3(0, 0, 0));
        for (int IKIteration = 0; IKIteration < maxFABRIKIteration && glm::l2Norm(ik.EndEffectorPosition() - EndPosition) > eps; IKIteration++) {
            // task: fabr ik
            // backward update
            glm::vec3 next_position         = EndPosition;
            backward_positions[nJoints - 1] = EndPosition;

            for (int i = nJoints - 2; i >= 0; i--) {
                // your code here
                backward_positions[i] = backward_positions[i+1]+glm::normalize(ik.JointGlobalPosition[i]-backward_positions[i+1])*glm::l2Norm(ik.JointGlobalPosition[i+1]-ik.JointGlobalPosition[i]);          
            }

            // forward update
            glm::vec3 now_position = ik.JointGlobalPosition[0];
            forward_positions[0] = ik.JointGlobalPosition[0];
            for (int i = 0; i < nJoints - 1; i++) {
                // your code here
                forward_positions[i+1] = forward_positions[i]+glm::normalize(backward_positions[i+1]-forward_positions[i])*glm::l2Norm(ik.JointGlobalPosition[i+1]-ik.JointGlobalPosition[i]);

            }
            ik.JointGlobalPosition = forward_positions; // copy forward positions to joint_positions
        }

        // Compute joint rotation by position here.
        for (int i = 0; i < nJoints - 1; i++) {
            ik.JointGlobalRotation[i] = glm::rotation(glm::normalize(ik.JointLocalOffset[i + 1]), glm::normalize(ik.JointGlobalPosition[i + 1] - ik.JointGlobalPosition[i]));
        }
        ik.JointLocalRotation[0] = ik.JointGlobalRotation[0];
        for (int i = 1; i < nJoints - 1; i++) {
            ik.JointLocalRotation[i] = glm::inverse(ik.JointGlobalRotation[i - 1]) * ik.JointGlobalRotation[i];
        }
        ForwardKinematics(ik, 0);//这句在干嘛？？注释掉也可以正常跑
    }
    /*IKSystem::Vec3ArrPtr IKSystem::BuildCustomTargetPosition() {
        // get function from https://www.wolframalpha.com/input/?i=Albert+Einstein+curve
        int nums = 5000;
        using Vec3Arr = std::vector<glm::vec3>;
        std::shared_ptr<Vec3Arr> custom(new Vec3Arr(nums));
        int index = 0;
        for (int i = 0; i < nums; i++) {
            float x_val = 1.5e-3f * custom_x(92 * glm::pi<float>() * i / nums);
            float y_val = 1.5e-3f * custom_y(92 * glm::pi<float>() * i / nums);
            if (std::abs(x_val) < 1e-3 || std::abs(y_val) < 1e-3) continue;
            (*custom)[index++] = glm::vec3(1.6f - x_val, 0.0f, y_val - 0.2f);
        }
        custom->resize(index);
        return custom;
    }*/

    /*IKSystem::Vec3ArrPtr IKSystem::BuildCustomTargetPosition() {
        // get function from https://www.wolframalpha.com/input/?i=Albert+Einstein+curve
        int nums = 5000;
        using Vec3Arr = std::vector<glm::vec3>;
        std::shared_ptr<Vec3Arr> custom(new Vec3Arr(nums));
        //bonus task:使点分布更均匀。
        //计算本次采样点和上次采样点的距离，若距离过大则进行重采样
        float len_bar=0.02f;
        float last_x,last_y;
        int index = 0;
        float x_val = 0.0f;
        float y_val = 0.0f;
       //(*custom)[index++] = glm::vec3(1.6f - x_val, 0.0f, y_val - 0.2f);
        last_x = x_val;
        last_y = y_val;
        for (int i = 1; i < nums; i++) {
            float x_val = 1.5e-3f * custom_x(92 * glm::pi<float>() * i / nums);
            float y_val = 1.5e-3f * custom_y(92 * glm::pi<float>() * i / nums);
            float dist = glm::sqrt((x_val - last_x) * (x_val - last_x) + (y_val - last_y) * (y_val - last_y));
            if(dist<len_bar/2)
            {
                if (std::abs(x_val) < 1e-3 || std::abs(y_val) < 1e-3) continue;
                last_x=x_val;
                last_y=y_val;
                (*custom)[index++] = glm::vec3(1.6f - x_val, 0.0f, y_val - 0.2f);
                continue;
            }
            for(int j=0;j<int(dist/len_bar);j++)
            {
                x_val = 1.5e-3f * custom_x(92 * glm::pi<float>() * (i*1.0-j*1.0/(int)(dist/len_bar)) / nums);
                y_val = 1.5e-3f * custom_y(92 * glm::pi<float>() * (i*1.0-j*1.0/(int)(dist/len_bar)) / nums);
                if (std::abs(x_val) < 1e-3 || std::abs(y_val) < 1e-3) continue;
                (*custom)[index++] = glm::vec3(1.6f - x_val, 0.0f, y_val - 0.2f);
            }
            last_x=x_val;
            last_y=y_val;
        }
        custom->resize(index);
        return custom;
    }*/

    IKSystem::Vec3ArrPtr IKSystem::BuildCustomTargetPosition(){
        int nums = 150;
        using Vec3Arr = std::vector<glm::vec3>;
        std::shared_ptr<Vec3Arr> custom(new Vec3Arr(2000));
        int index = 0;
        //绘制T
        for(int i = 0; i < nums; i++){
            float x_val = 0.5*i/nums;
            float y_val = 0.5;
            (*custom)[index++] = glm::vec3(0.6+x_val, 0.0f, y_val);
        }
        for(int i = 0; i < nums; i++){
            float x_val = 0.85;
            float y_val = 0.5*i/nums;
            (*custom)[index++] = glm::vec3(x_val, 0.0f, y_val);
        }
        //绘制J
        float pi=glm::pi<float>();
        for(int i = 0; i < nums; i++){
            float x_val = 0.5*i/nums;
            float y_val = 0.5;
            (*custom)[index++] = glm::vec3(x_val, 0.0f, y_val);
        }
        for(int i = 0; i < nums; i++){
            float x_val = 0.25;
            float y_val = 0.5 - 0.375*i/nums;
            (*custom)[index++] = glm::vec3(x_val, 0.0f, y_val);
        }
        for(int i = 0; i < nums; i++){
            //以（0.125，0.125）为圆心，半径0.125画四分之一圆弧
            float theta = pi+pi*i/nums;
            float x_val = 0.375 + 0.125*glm::cos(theta);
            float y_val = 0.125 + 0.125*glm::sin(theta);
            (*custom)[index++] = glm::vec3(x_val, 0.0f, y_val);
        }
        //绘制C
        for(int i = 0; i < nums; i++){
            float theta=30.0f+300.0f*(i/float(nums));
            float x_val = 0.5 + 0.25*glm::cos(glm::radians(theta));
            float y_val = 0.25 + 0.25*glm::sin(glm::radians(theta));
            (*custom)[index++] = glm::vec3(0.25-x_val, 0.0f, y_val);
        }
        custom->resize(index);
        return custom;
    }

    static Eigen::VectorXf glm2eigen(std::vector<glm::vec3> const & glm_v) {
        Eigen::VectorXf v = Eigen::Map<Eigen::VectorXf const, Eigen::Aligned>(reinterpret_cast<float const *>(glm_v.data()), static_cast<int>(glm_v.size() * 3));
        return v;
    }

    static std::vector<glm::vec3> eigen2glm(Eigen::VectorXf const & eigen_v) {
        return std::vector<glm::vec3>(
            reinterpret_cast<glm::vec3 const *>(eigen_v.data()),
            reinterpret_cast<glm::vec3 const *>(eigen_v.data() + eigen_v.size())
        );
    }

    static Eigen::SparseMatrix<float> CreateEigenSparseMatrix(std::size_t n, std::vector<Eigen::Triplet<float>> const & triplets) {
        Eigen::SparseMatrix<float> matLinearized(n, n);
        matLinearized.setFromTriplets(triplets.begin(), triplets.end());
        return matLinearized;
    }

    // solve Ax = b and return x
    static Eigen::VectorXf ComputeSimplicialLLT(
        Eigen::SparseMatrix<float> const & A,
        Eigen::VectorXf const & b) {
        auto solver = Eigen::SimplicialLLT<Eigen::SparseMatrix<float>>(A);
        return solver.solve(b);
    }

    void AdvanceMassSpringSystem(MassSpringSystem & system, float const dt) {
        // your code here: rewrite following code
        int const steps = 1000;
        //float const ddt = dt / steps; 
        //for (std::size_t s = 0; s < steps; s++) {
            /*std::vector<glm::vec3> forces(system.Positions.size(), glm::vec3(0));
            for (auto const spring : system.Springs) {
                auto const p0 = spring.AdjIdx.first;
                auto const p1 = spring.AdjIdx.second;
                glm::vec3 const x01 = system.Positions[p1] - system.Positions[p0];
                glm::vec3 const v01 = system.Velocities[p1] - system.Velocities[p0];
                glm::vec3 const e01 = glm::normalize(x01);
                glm::vec3 f = (system.Stiffness * (glm::length(x01) - spring.RestLength) + system.Damping * glm::dot(v01, e01)) * e01;
                forces[p0] += f;
                forces[p1] -= f;
            }
            for (std::size_t i = 0; i < system.Positions.size(); i++) {
                if (system.Fixed[i]) continue;
                system.Velocities[i] += (glm::vec3(0, -system.Gravity, 0) + forces[i] / system.Mass) * ddt;
                system.Positions[i] += system.Velocities[i] * ddt;
            }*/
            // implicit euler
        int n = system.Positions.size();
        //1.计算内力fij和fji，加到对应点的内力上，得到forces向量即为E的负梯度
        std::vector<glm::vec3> forces(system.Positions.size(), glm::vec3(0));
        for (auto const spring : system.Springs) {
            auto const p0 = spring.AdjIdx.first;
            auto const p1 = spring.AdjIdx.second;
            glm::vec3 const x01 = system.Positions[p1] - system.Positions[p0];
            //glm::vec3 const v01 = system.Velocities[p1] - system.Velocities[p0];
            glm::vec3 const e01 = glm::normalize(x01);
            glm::vec3 f = system.Stiffness * (glm::length(x01) - spring.RestLength) * e01;//无需阻尼项
            forces[p0] += f;
            forces[p1] -= f;
        }
        //2.计算E的Hessian矩阵
        std::vector<Eigen::Triplet<float>> triplets;
        for (auto const spring : system.Springs) {
            auto const p0 = spring.AdjIdx.first;
            auto const p1 = spring.AdjIdx.second;
            glm::vec3 const x10 = system.Positions[p0] - system.Positions[p1];
            glm::vec3 const e01 = glm::normalize(x10);
            float l_ij = glm::length(x10);
            glm::mat3 H_ij = system.Stiffness * ( glm::outerProduct(e01, e01) + (1 - spring.RestLength / l_ij) * (glm::mat3(1.0f) - glm::outerProduct(e01, e01)) / l_ij );
            for(int row=0;row<3;row++)
            {
                for(int column=0;column<3;column++)
                {
                    triplets.push_back(Eigen::Triplet<float>(3*p0+row, 3*p0+column, H_ij[row][column]));
                    triplets.push_back(Eigen::Triplet<float>(3*p1+row, 3*p1+column, H_ij[row][column]));
                    triplets.push_back(Eigen::Triplet<float>(3*p0+row, 3*p1+column, -H_ij[row][column]));
                    triplets.push_back(Eigen::Triplet<float>(3*p1+row, 3*p0+column, -H_ij[row][column]));
                }
            }
        }
        auto H_E= CreateEigenSparseMatrix(n * 3, triplets);

        //3.计算y_tk
        Eigen::VectorXf v = glm2eigen(system.Velocities);
        Eigen::VectorXf x = glm2eigen(system.Positions);
        Eigen::VectorXf gravity(n * 3);
        gravity.setZero();
        for(int i=0;i<n;i++)
            gravity[3*i+1]=-system.Gravity;
        Eigen::VectorXf y=x + dt*v + dt*dt*gravity;
        
        //4.计算g的梯度和Hessian矩阵
        //构建M_diag
        Eigen::SparseMatrix<float> M_diag(n * 3, n * 3);
        for (int i = 0; i < n * 3; i++) 
            M_diag.insert(i, i) = system.Mass;  
        //计算E的梯度
        Eigen::VectorXf E_grad = -glm2eigen(forces);
        //计算g的梯度
        Eigen::VectorXf g_grad = 1/(dt*dt)*M_diag*(x-y)+E_grad;
        //计算g的Hessian矩阵
        Eigen::SparseMatrix<float> g_Hessian = 1/(dt*dt)*M_diag + H_E;

        //5.求解线性方程组
        Eigen::VectorXf delta_x = ComputeSimplicialLLT(g_Hessian, -g_grad);

        //6.更新位置和速度
        x += delta_x;
        v = delta_x/dt;
        std::vector<glm::vec3> new_Positions = eigen2glm(x);
        std::vector<glm::vec3> new_Velocities = eigen2glm(v);
        for(std::size_t i = 0; i < system.Positions.size(); i++) {
            if (system.Fixed[i]) continue;
            system.Positions[i] = new_Positions[i];
            system.Velocities[i] = new_Velocities[i];
        }

        //}
    }
}
