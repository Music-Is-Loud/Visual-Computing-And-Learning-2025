#version 410 core

layout (location = 0) in vec2 v_TexCoord;

uniform sampler2D u_DiffuseMap;

void main() {
    //不渲染颜色，只写入深度，片段着色器只负责丢弃透明片段，不透明片段写入深度贴图
    vec4 diffuseFactor = texture(u_DiffuseMap , v_TexCoord).rgba;
    if (diffuseFactor.a < .2) discard;
}