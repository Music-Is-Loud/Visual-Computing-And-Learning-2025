#version 410 core

layout(location = 0) in  vec3 a_Position;

layout(location = 0) out vec3 v_TexCoord;

struct Light {
    vec3  Intensity;
    vec3  Direction;   // For spot and directional lights.
    vec3  Position;    // For point and spot lights.
    float CutOff;      // For spot lights.
    float OuterCutOff; // For spot lights.
};

layout(std140) uniform PassConstants {
    mat4  u_Projection;
    mat4  u_View;
    vec3  u_ViewPosition;
    vec3  u_AmbientIntensity;
    Light u_Lights[4];
    int   u_CntPointLights;
    int   u_CntSpotLights;
    int   u_CntDirectionalLights;
};

void main() {
    v_TexCoord  = a_Position;
    
    // your code here
    // 真实空间坐标转换为裁剪空间坐标
    // gl_Position=u_Projection×u_View×u_Model×vec4(a_Position,1.0)
    // u_Model矩阵表示顶点在本地空间到世界空间的变换，此处不需要
    // u_View矩阵表示世界空间到观察空间的变换,但天空盒不应随摄像机位置变化而变化，因此去掉平移分量
    // u_Projection矩阵表示观察空间到裁剪空间的变换
    mat4 view = mat4(mat3(u_View));// 去掉平移分量
    vec4 pos = u_Projection * view * vec4(a_Position, 1.0);
    gl_Position = pos.xyww;// 保证透视除法后z值为1.0，即最大深度值，使得天空盒总在最远处
}
