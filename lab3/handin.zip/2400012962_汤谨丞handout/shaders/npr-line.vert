#version 410 core

layout(location = 0) in  vec3 a_Position;//模型顶点位置
layout(location = 1) in  vec3 a_Normal;//模型法线

struct Light {
    vec3  Intensity;
    vec3  Direction;   // For spot and directional lights.
    vec3  Position;    // For point and spot lights.
    float CutOff;      // For spot lights.
    float OuterCutOff; // For spot lights.
};

layout(std140) uniform PassConstants {
    mat4  u_Projection;//世界坐标转到相机坐标
    mat4  u_View;// 相机坐标转到裁剪坐标（透视效果或者正交投影）
    vec3  u_ViewPosition;
    vec3  u_AmbientIntensity;
    Light u_Lights[4];
    int   u_CntPointLights;
    int   u_CntSpotLights;
    int   u_CntDirectionalLights;
};

uniform int u_ScreenWidth;
uniform int u_ScreenHeight;
uniform float u_LineWidth;

void main() {
    vec4 clipPos = u_Projection * u_View * vec4(a_Position, 1.);//计算裁剪空间位置
    vec3 clipNorm = mat3(u_Projection) * mat3(u_View) * a_Normal;//计算裁剪空间法线
    vec2 offset = normalize(clipNorm.xy) / vec2(u_ScreenWidth, u_ScreenHeight) * u_LineWidth * clipPos.w * 2;
    //只取法线在屏幕平面上的方向（在屏幕上沿法线方向膨胀），并进行根据屏幕尺寸进行归一化（避免长宽比例导致的线宽不同）
    //再乘以线宽和w分量（实际上是按照深度调整偏移量）进行缩放使得近处和远处的线宽保持一致
    clipPos.xy += offset;
    gl_Position = clipPos;
}
