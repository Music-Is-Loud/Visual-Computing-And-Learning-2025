#version 410 core

layout(location = 0) in  vec3 v_Position;
layout(location = 1) in  vec3 v_Normal;
layout(location = 2) in  vec2 v_TexCoord;

layout(location = 0) out vec4 f_Color;

struct Light {
    vec3  Intensity;
    vec3  Direction;   // For spot and directional lights.
    vec3  Position;    // For point and spot lights.
    float CutOff;      // For spot lights.
    float OuterCutOff; // For spot lights.
};

layout(std140) uniform PassConstants {
    mat4  u_Projection;
    mat4  u_View;
    vec3  u_ViewPosition;
    vec3  u_AmbientIntensity;
    Light u_Lights[4];
    int   u_CntPointLights;
    int   u_CntSpotLights;
    int   u_CntDirectionalLights;
};

uniform float u_AmbientScale;
uniform bool  u_UseBlinn;
uniform float u_Shininess;
uniform bool  u_UseGammaCorrection;
uniform int   u_AttenuationOrder;
uniform float u_BumpMappingBlend;

uniform sampler2D u_DiffuseMap;
uniform sampler2D u_SpecularMap;
uniform sampler2D u_HeightMap;

vec3 Shade(vec3 lightIntensity, vec3 lightDir, vec3 normal, vec3 viewDir, vec3 diffuseColor, vec3 specularColor, float shininess) {
    // your code here:
    //vec3 ambient = u_AmbientIntensity * u_AmbientScale * diffuseColor;
    vec3 diffuse = max(dot(normal, lightDir), 0.0) * lightIntensity * diffuseColor;
    if(!u_UseBlinn)//使用phong模型计算高光，计算反射向量
    {
        vec3 reflectDir = reflect(-lightDir, normal);//此处已经是归一化的向量
        vec3 specular = pow(max(dot(viewDir, reflectDir), 0.0), shininess) * lightIntensity * specularColor;
        return  diffuse + specular;
    }
    else//使用blinn-phong模型计算高光，计算角平分线向量
    {
        vec3 halfDir = normalize(lightDir + viewDir);//归一化角平分线向量
        vec3 specular = pow(max(dot(normal, halfDir), 0.0), shininess) * lightIntensity * specularColor;
        return  diffuse + specular;
    }
    
}

vec3 GetNormal() {
    // Bump mapping from paper: Bump Mapping Unparametrized Surfaces on the GPU
    vec3 vn = normalize(v_Normal);//当前片元的法线

    // your code here:
    vec3 bumpNormal = vn;
    //计算当前片元在世界坐标中沿屏幕 X/Y 方向的微小变化，在屏幕空间（纹理坐标(u,v))的偏导方向，他们未必与法线垂直
    //dFdx, dFdy 返回相邻像素之间的差分，可用于构造局部表面坐标系
    vec3 posDX = dFdx(v_Position);
    vec3 posDY = dFdy(v_Position);
    //构造texture(u,v)的两个切线向量
    vec3 r1 = cross(posDY, vn);
    vec3 r2 = cross(vn, posDX);
    float det=dot(posDX,r1); //计算雅可比行列式的值，用于确定局部坐标系的朝向
    //从高度贴图读取当前片元和相邻片元的高度
    float Hll = texture(u_HeightMap, v_TexCoord).r;//当前片元高度
    float Hlr = texture(u_HeightMap, v_TexCoord + dFdx(v_TexCoord)).r;//x方向相邻片元高度
    float Hul = texture(u_HeightMap, v_TexCoord + dFdy(v_TexCoord)).r;//y方向相邻片元高度
    // 计算局部梯度
    float dHdX = (Hlr - Hll);//x方向高度变化
    float dHdY = (Hul - Hll);//y方向高度变化
    //计算扰动后的法线
    vec3 surf_grad=sign(det) * (dHdX * r1 + dHdY * r2);
    bumpNormal = normalize(abs(det)*vn - surf_grad);
    //如果bumpNormal包含NaN值则返回原始法线，否则根据混合系数返回最终法线
    return bumpNormal != bumpNormal ? vn : normalize(vn * (1. - u_BumpMappingBlend) + bumpNormal * u_BumpMappingBlend);
}

void main() {
    float gamma          = 2.2;
    vec4  diffuseFactor  = texture(u_DiffuseMap , v_TexCoord).rgba;//获得漫反射贴图的颜色值+透明度
    vec4  specularFactor = texture(u_SpecularMap, v_TexCoord).rgba;//获得镜面反射贴图的颜色值+高光强度
    //一旦透明度过低或者是镂空图案则丢弃该片元
    //不设置为0是为了压缩或采样后带一点模糊，防止半透明表面出现错误渲染
    //if (diffuseFactor.a < .0) discard;
    if (diffuseFactor.a < .2) discard;
    vec3  diffuseColor   = u_UseGammaCorrection ? pow(diffuseFactor.rgb, vec3(gamma)) : diffuseFactor.rgb;//如果使用伽马校正，额外处理漫反射颜色
    vec3  specularColor  = specularFactor.rgb;
    float shininess      = u_Shininess < 0 ? specularFactor.a * 256 : u_Shininess;//如果外部没有指定高光指数，则使用贴图的alpha通道控制高光指数
    vec3  normal         = GetNormal();
    vec3  viewDir        = normalize(u_ViewPosition - v_Position);
    // Ambient component.
    vec3  total = u_AmbientIntensity * u_AmbientScale * diffuseColor;//环境光，用kd近似代替了ka
    // Iterate lights.
    // 遍历所有点光源
    for (int i = 0; i < u_CntPointLights; i++) {
        vec3  lightDir     = normalize(u_Lights[i].Position - v_Position);
        float dist         = length(u_Lights[i].Position - v_Position);
        float attenuation  = 1. / (u_AttenuationOrder == 2 ? dist * dist : (u_AttenuationOrder == 1  ? dist : 1.));
        total             += Shade(u_Lights[i].Intensity, lightDir, normal, viewDir, diffuseColor, specularColor, shininess) * attenuation;
    }
    //遍历所有平行光源
    for (int i = u_CntPointLights + u_CntSpotLights; i < u_CntPointLights + u_CntSpotLights + u_CntDirectionalLights; i++) {
        total += Shade(u_Lights[i].Intensity, u_Lights[i].Direction, normal, viewDir, diffuseColor, specularColor, shininess);
    }
    // Gamma correction.
    f_Color = vec4(u_UseGammaCorrection ? pow(total, vec3(1. / gamma)) : total, 1.);
}
