#include "Labs/3-Rendering/tasks.h"

namespace VCX::Labs::Rendering {

    glm::vec4 GetTexture(Engine::Texture2D<Engine::Formats::RGBA8> const & texture, glm::vec2 const & uvCoord) {
        if (texture.GetSizeX() == 1 || texture.GetSizeY() == 1) return texture.At(0, 0);
        glm::vec2 uv      = glm::fract(uvCoord);
        uv.x              = uv.x * texture.GetSizeX() - .5f;
        uv.y              = uv.y * texture.GetSizeY() - .5f;
        std::size_t xmin  = std::size_t(glm::floor(uv.x) + texture.GetSizeX()) % texture.GetSizeX();
        std::size_t ymin  = std::size_t(glm::floor(uv.y) + texture.GetSizeY()) % texture.GetSizeY();
        std::size_t xmax  = (xmin + 1) % texture.GetSizeX();
        std::size_t ymax  = (ymin + 1) % texture.GetSizeY();
        float       xfrac = glm::fract(uv.x), yfrac = glm::fract(uv.y);
        return glm::mix(glm::mix(texture.At(xmin, ymin), texture.At(xmin, ymax), yfrac), glm::mix(texture.At(xmax, ymin), texture.At(xmax, ymax), yfrac), xfrac);
    }

    glm::vec4 GetAlbedo(Engine::Material const & material, glm::vec2 const & uvCoord) {
        glm::vec4 albedo       = GetTexture(material.Albedo, uvCoord);
        glm::vec3 diffuseColor = albedo;
        return glm::vec4(glm::pow(diffuseColor, glm::vec3(2.2)), albedo.w);
    }

    /******************* 1. Ray-triangle intersection *****************/
    bool IntersectTriangle(Intersection & output, Ray const & ray, glm::vec3 const & p1, glm::vec3 const & p2, glm::vec3 const & p3) {
        // your code here
        glm::mat3 A=glm::mat3(-(ray.Direction),p2 - p1,p3 - p1);
        //使用克莱姆法则求解线性方程组
        /*float detA=glm::determinant(A);
        if(detA<1e-6f and detA>-1e-6f) return false;
        glm::vec3 b=-p1 + ray.Origin;
        glm::mat3 At=glm::mat3(b,p2 - p1,p3 - p1);
        glm::mat3 Au=glm::mat3(-(ray.Direction),b,p3 - p1);
        glm::mat3 Av=glm::mat3(-(ray.Direction),p2 - p1,b);
        float t=glm::determinant(At)/detA;
        float u=glm::determinant(Au)/detA;
        float v=glm::determinant(Av)/detA;
        if(u<0.0f||v<0.0f||u+v>1.0f||t<0.0f) return false;
        output.t=t;
        output.u=u;
        output.v=v;*/
        //使正统的Moller–Trumbore算法
        glm::vec3 e1=p2-p1;
        glm::vec3 e2=p3-p1;
        glm::vec3 h=glm::cross(ray.Direction,e2);
        float detA=glm::dot(e1,h);
        if(detA<1e-6f and detA>-1e-6f) return false;
        float invDet=1.0f/detA;
        glm::vec3 s=ray.Origin - p1;
        float u=glm::dot(s,h)*invDet;
        if(u<0.0f||u>1.0f) return false;
        glm::vec3 q=glm::cross(s,e1);
        float v=glm::dot(ray.Direction,q)*invDet;
        if(v<0.0f||u+v>1.0f) return false;
        float t=glm::dot(e2,q)*invDet;
        if(t<0.0f) return false;
        output.t=t;
        output.u=u;     
        output.v=v;
        return true;
    }
}
namespace VCX::Labs::Rendering {

    glm::vec3 RayTrace(const RayIntersector & intersector, Ray ray, int maxDepth, bool enableShadow) {
        glm::vec3 color(0.0f);
        glm::vec3 weight(1.0f);

        for (int depth = 0; depth < maxDepth; depth++) {
            auto rayHit = intersector.IntersectRay(ray);
            if (! rayHit.IntersectState) return color;
            const glm::vec3 pos       = rayHit.IntersectPosition;
            const glm::vec3 n         = rayHit.IntersectNormal;
            const glm::vec3 kd        = rayHit.IntersectAlbedo;
            const glm::vec3 ks        = rayHit.IntersectMetaSpec;
            const float     alpha     = rayHit.IntersectAlbedo.w;
            const float     shininess = rayHit.IntersectMetaSpec.w * 256;

            glm::vec3 result(0.0f);//当前击中点的局部光照结果
            /******************* 2. Whitted-style ray tracing *****************/
            // your code here
            result+=intersector.InternalScene->AmbientIntensity*kd;//环境光照
            for (const Engine::Light & light : intersector.InternalScene->Lights) {
                glm::vec3 l;
                float     attenuation;
                /******************* 3. Shadow ray *****************/
                if (light.Type == Engine::LightType::Point) {//点光源
                    l           = light.Position - pos;//光源方向
                    attenuation = 1.0f / glm::dot(l, l);//衰减程度
                    if (enableShadow) {//需要阴影检测，可能需要跳过该光源贡献
                        // your code here
                        Ray shadowRay=Ray(pos,glm::normalize(l));//从击中点向光源发射阴影射线
                        auto shadowHit=intersector.IntersectRay(shadowRay);
                        //auto initshadowHit=shadowHit;
                        bool inshadow=false;
                        while(shadowHit.IntersectState)
                        {
                            //如果击中物体在光源后侧,说明光线已经到达光源位置,不在阴影里（对于平行光源不用这一项）
                            if(glm::dot(light.Position - shadowHit.IntersectPosition, l)<0.0f)
                            {
                                break;
                            }
                            if(shadowHit.IntersectAlbedo.w>=0.2f)
                            {
                                inshadow=true;
                                break;//被遮挡，跳过该光源贡献
                            }
                            shadowRay=Ray(shadowHit.IntersectPosition,glm::normalize(l));
                            shadowHit=intersector.IntersectRay(shadowRay);
                        }
                        if(inshadow) continue;
                    }      
                } 
                else if (light.Type == Engine::LightType::Directional) {//平行光源
                    l           = light.Direction;
                    attenuation = 1.0f;
                    if (enableShadow) {
                        // your code here
                        Ray shadowRay=Ray(pos,glm::normalize(l));
                        auto shadowHit=intersector.IntersectRay(shadowRay);
                        bool inshadow=false;
                        while(shadowHit.IntersectState)
                        {
                            if(shadowHit.IntersectAlbedo.w>=0.2f)
                            {
                                inshadow=true;
                                break;//被遮挡，跳过该光源贡献
                            }
                            shadowRay=Ray(shadowHit.IntersectPosition,glm::normalize(l));
                            shadowHit=intersector.IntersectRay(shadowRay);
                        }
                        if(inshadow) continue;
                    }
                }

                /******************* 2. Whitted-style ray tracing *****************/
                // your code here
                glm::vec3 diffuse=fmax(glm::dot(glm::normalize(n),glm::normalize(l)),0.0f)*kd*light.Intensity*attenuation;//漫反射
                glm::vec3 viewDir=glm::normalize(-ray.Direction);
                glm::vec3 halfDir=glm::normalize(glm::normalize(l)+viewDir);
                glm::vec3 specular=glm::pow(fmax(glm::dot(glm::normalize(n),halfDir),0.0f),shininess)*ks*light.Intensity*attenuation;//镜面反射
                result+=diffuse+specular;


            }

            if (alpha < 0.9) {
                // refraction折射
                // accumulate color
                glm::vec3 R = alpha * glm::vec3(1.0f);
                color += weight * R * result;
                weight *= glm::vec3(1.0f) - R;

                // generate new ray
                ray = Ray(pos, ray.Direction);
            } else {
                // reflection反射
                // accumulate color
                glm::vec3 R = ks * glm::vec3(0.5f);
                color += weight * (glm::vec3(1.0f) - R) * result;
                weight *= R;

                // generate new ray
                glm::vec3 out_dir = ray.Direction - glm::vec3(2.0f) * n * glm::dot(n, ray.Direction);
                ray               = Ray(pos, out_dir);
            }
        }

        return color;
    }
} // namespace VCX::Labs::Rendering