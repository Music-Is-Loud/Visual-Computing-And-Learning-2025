#include <unordered_map>
#include <algorithm>
#include <glm/gtc/matrix_inverse.hpp>
#include <spdlog/spdlog.h>

#include "Labs/2-GeometryProcessing/DCEL.hpp"
#include "Labs/2-GeometryProcessing/tasks.h"

namespace VCX::Labs::GeometryProcessing {

#include "Labs/2-GeometryProcessing/marching_cubes_table.h"

    /******************* 1. Mesh Subdivision *****************/
    void SubdivisionMesh(Engine::SurfaceMesh const & input, Engine::SurfaceMesh & output, std::uint32_t numIterations) {
        Engine::SurfaceMesh curr_mesh = input;
        // We do subdivison iteratively.
        for (std::uint32_t it = 0; it < numIterations; ++it) {
            // During each iteration, we first move curr_mesh into prev_mesh.
            Engine::SurfaceMesh prev_mesh;
            prev_mesh.Swap(curr_mesh);
            // Then we create doubly connected edge list.
            DCEL G(prev_mesh);
            if (! G.IsManifold()) {
                spdlog::warn("VCX::Labs::GeometryProcessing::SubdivisionMesh(..): Non-manifold mesh.");
                return;
            }
            // Note that here curr_mesh has already been empty.
            // We reserve memory first for efficiency.
            curr_mesh.Positions.reserve(prev_mesh.Positions.size() * 3 / 2);
            curr_mesh.Indices.reserve(prev_mesh.Indices.size() * 4);
            // Then we iteratively update currently existing vertices.
            for (std::size_t i = 0; i < prev_mesh.Positions.size(); ++i) {
                // Update the currently existing vetex v from prev_mesh.Positions.
                // Then add the updated vertex into curr_mesh.Positions.
                auto v           = G.Vertex(i);
                auto neighbors   = v->Neighbors();
                // your code here:对于每一个原有的顶点，重新求其坐标
                int n=neighbors.size();
                float u=3.0f/(8*n);
                if(n==3) u=3.0f/16;
                auto new_v_pos=(1-n*u)*prev_mesh.Positions[i];
                for(std::size_t j=0;j<n;j++)
                {
                    new_v_pos+=u*prev_mesh.Positions[neighbors[j]];
                }
                curr_mesh.Positions.push_back(new_v_pos);
                
            }
            // We create an array to store indices of the newly generated vertices.
            // Note: newIndices[i][j] is the index of vertex generated on the "opposite edge" of j-th
            //       vertex in the i-th triangle.
            std::vector<std::array<std::uint32_t, 3U>> newIndices(prev_mesh.Indices.size() / 3, { ~0U, ~0U, ~0U });
            // Iteratively process each halfedge.
            for (auto e : G.Edges()) {
                // newIndices[face index][vertex index] = index of the newly generated vertex
                newIndices[G.IndexOf(e->Face())][e->EdgeLabel()] = curr_mesh.Positions.size();
                auto eTwin                                       = e->TwinEdgeOr(nullptr);
                // eTwin stores the twin halfedge.
                if (! eTwin) {
                    // When there is no twin halfedge (so, e is a boundary edge):
                    // your code here: generate the new vertex and add it into curr_mesh.Positions.
                    auto new_v=(prev_mesh.Positions[e->To()]+prev_mesh.Positions[e->From()])*0.5f;
                    curr_mesh.Positions.push_back(new_v);
                } else {
                    // When the twin halfedge exists, we should also record:
                    //     newIndices[face index][vertex index] = index of the newly generated vertex
                    // Because G.Edges() will only traverse once for two halfedges,
                    //     we have to record twice.两条半边对应生成的是同一个点
                    newIndices[G.IndexOf(eTwin->Face())][e->TwinEdge()->EdgeLabel()] = curr_mesh.Positions.size();
                    // your code here: generate the new vertex and add it into curr_mesh.Positions.
                    auto new_v=0.375f*(prev_mesh.Positions[e->From()]+prev_mesh.Positions[e->To()])
                              +0.125f*(prev_mesh.Positions[e->NextEdge()->To()]+prev_mesh.Positions[eTwin->PrevEdge()->From()]);
                    curr_mesh.Positions.push_back(new_v);
                }
            }

            // Here we've already build all the vertices.
            // Next, it's time to reconstruct face indices.
            for (std::size_t i = 0; i < prev_mesh.Indices.size(); i += 3U) {
                // For each face F in prev_mesh, we should create 4 sub-faces.
                // v0,v1,v2 are indices of vertices in F.
                // m0,m1,m2 are generated vertices on the edges of F.
                auto v0           = prev_mesh.Indices[i + 0U];
                auto v1           = prev_mesh.Indices[i + 1U];
                auto v2           = prev_mesh.Indices[i + 2U];
                auto [m0, m1, m2] = newIndices[i / 3U];
                // Note: m0 is on the opposite edge (v1-v2) to v0.
                // Please keep the correct indices order (consistent with order v0-v1-v2)
                //     when inserting new face indices.
                // toInsert[i][j] stores the j-th vertex index of the i-th sub-face.
                std::uint32_t toInsert[4][3] = {
                    // your code here:
                    {v0, m2, m1},
                    {v1, m0, m2},
                    {v2, m1, m0},
                    {m0, m1, m2}
                };
                // Do insertion.
                curr_mesh.Indices.insert(
                    curr_mesh.Indices.end(),
                    reinterpret_cast<std::uint32_t *>(toInsert),
                    reinterpret_cast<std::uint32_t *>(toInsert) + 12U
                );
            }

            if (curr_mesh.Positions.size() == 0) {
                spdlog::warn("VCX::Labs::GeometryProcessing::SubdivisionMesh(..): Empty mesh.");
                output = input;
                return;
            }
        }
        // Update output.
        output.Swap(curr_mesh);
    }

    /******************* 2. Mesh Parameterization *****************/
    void Parameterization(Engine::SurfaceMesh const & input, Engine::SurfaceMesh & output, const std::uint32_t numIterations) {
        // Copy.
        output = input;
        // Reset output.TexCoords.
        output.TexCoords.resize(input.Positions.size(), glm::vec2 { 0 });

        // Build DCEL.
        DCEL G(input);
        if (! G.IsManifold()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::Parameterization(..): non-manifold mesh.");
            return;
        }
        // Set boundary UVs for boundary vertices.
        // your code here: directly edit output.TexCoords
        std::vector<DCEL::VertexIdx> boundary_vertices;
       
        auto start_v=G.Vertex(0);
        //找到第一个边界点
        int i;
        for(i=0;i<G.NumOfVertices();i++)
        {
            if(G.Vertex(i)->OnBoundary())
            {
                start_v=G.Vertex(i);
                break;
            }
        }
        std::vector<bool> visited(G.NumOfVertices(),false);//记录哪些点是边界点
        auto boundary_v_index=start_v->BoundaryNeighbors().first;
        while(boundary_v_index!=i)
        {
            visited[boundary_v_index]=true;
            boundary_vertices.push_back(boundary_v_index);
            boundary_v_index=G.Vertex(boundary_v_index)->BoundaryNeighbors().first;
        }
        const float PI=3.14159265358979323846f;
        //boundary_vertices.erase(std::unique(boundary_vertices.begin(),boundary_vertices.end()),boundary_vertices.end());
        int boundary_size=boundary_vertices.size();
        for(int i=0;i<boundary_size;i++)
        {
            float theta=2.0f*PI*float(i)/float(boundary_size);//均匀分布在圆周上，计算出角度
            output.TexCoords[boundary_vertices[i]]=glm::vec2(0.5f+0.5f*cos(theta),0.5f+0.5f*sin(theta));//坐标数值在[0,1]之间，以(0.5,0.5)为圆心
        }    
        // Solve equation via Gauss-Seidel Iterative Method.
        for (int k = 0; k < numIterations; ++k) {
            // your code here:
            for(int i=0;i<output.Positions.size();i++)//遍历所有顶点
            {
                //如果是边界顶点则跳过
                if(visited[i])
                    continue;
                auto v=G.Vertex(i);
                auto neighbors=v->Neighbors();
                glm::vec2 new_uv(0.0f,0.0f);
                for(auto n:neighbors)//遍历所有相邻顶点，认为他们的值都是对的，把他们代入方程
                {
                    new_uv+=output.TexCoords[n];
                }
                new_uv/=float(neighbors.size());
                output.TexCoords[i]=new_uv;
            }
        }
    }

    /******************* 3. Mesh Simplification *****************/
    void SimplifyMesh(Engine::SurfaceMesh const & input, Engine::SurfaceMesh & output, float simplification_ratio) {

        DCEL G(input);
        if (! G.IsManifold()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::SimplifyMesh(..): Non-manifold mesh.");
            return;
        }
        // We only allow watertight mesh.
        if (! G.IsWatertight()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::SimplifyMesh(..): Non-watertight mesh.");
            return;
        }

        // Copy.
        output = input;

        // Compute Kp matrix of the face f.
        auto UpdateQ {
            [&G, &output] (DCEL::Triangle const * f) -> glm::mat4 {
                glm::mat4 Kp;
                // your code here:
                glm::vec3 v0=output.Positions[f->VertexIndex(0)];
                glm::vec3 v1=output.Positions[f->VertexIndex(1)];   
                glm::vec3 v2=output.Positions[f->VertexIndex(2)];
                glm::vec3 normal=glm::normalize(glm::cross(v1-v0,v2-v0));//单位化法向量，求出(A,B,C) 
                float d=-glm::dot(normal,v0);
                glm::vec4 plane_eq(normal,d);//平面方程Ax+By+Cz+D=0对应的向量
                Kp=glm::outerProduct(plane_eq,plane_eq);//Kp=plane_eq*plane_eq^T
                return Kp;
            }
        };

        // The struct to record contraction info.
        struct ContractionPair {
            DCEL::HalfEdge const * edge;            // which edge to contract; if $edge == nullptr$, it means this pair is no longer valid
            glm::vec4              targetPosition;  // the targetPosition $v$ for vertex $edge->From()$ to move to 齐次坐标
            float                  cost;            // the cost $v.T * Qbar * v$
        };

        // Given an edge (v1->v2), the positions of its two endpoints (p1, p2) and the Q matrix (Q1+Q2),
        //     return the ContractionPair struct.
        static constexpr auto MakePair {
            [] (DCEL::HalfEdge const * edge,
                glm::vec3 const & p1,
                glm::vec3 const & p2,
                glm::mat4 const & Q
            ) -> ContractionPair {
                // your code here:
                ContractionPair pair;
                pair.edge=edge;
                glm::mat4 Qbar=Q;
                Qbar[0][3]=0.0f;Qbar[1][3]=0.0f;Qbar[2][3]=0.0f;Qbar[3][3]=1.0f;//构造Q‘矩阵 列优先储存！！
                glm::mat4 Qbar_inv=glm::inverse(Qbar);
                glm::vec4 v;
                if(abs(glm::determinant(Qbar))<0.001f)//如果Q'不可逆 找中点、v1、v2中cost最小的
                {
                    glm::vec3 mid_pos=0.5f*(p1+p2);
                    v=glm::vec4(mid_pos,1.0f);
                    pair.cost=glm::dot(v, Q*v);
                    glm::vec4 v1=glm::vec4(p1,1.0f);
                    glm::vec4 v2=glm::vec4(p2,1.0f);
                    float cost1=glm::dot(v1, Q*v1);
                    float cost2=glm::dot(v2, Q*v2);
                    if(cost1<pair.cost)
                    {
                        pair.cost=cost1;
                        v=v1;
                    }
                    if(cost2<pair.cost)  
                    {
                        pair.cost=cost2;
                        v=v2;
                    }
                }
                else
                {
                    v=Qbar_inv*glm::vec4(0.0f,0.0f,0.0f,1.0f);
                    pair.cost=glm::dot(v, Q*v);//计算cost
                }
                //v=glm::vec4(0.5f*(p1+p2),1.0f);
                pair.targetPosition=v;
                //pair.cost=glm::dot(v, Q*v);
                return pair;
            }
        };

        // pair_map: map EdgeIdx to index of $pairs$
        // pairs:    store ContractionPair
        // Qv:       $Qv[idx]$ is the Q matrix of vertex with index $idx$
        // Kf:       $Kf[idx]$ is the Kp matrix of face with index $idx$
        std::unordered_map<DCEL::EdgeIdx, std::size_t> pair_map; 
        std::vector<ContractionPair>                  pairs; 
        std::vector<glm::mat4>                         Qv(G.NumOfVertices(), glm::mat4(0));
        std::vector<glm::mat4>                         Kf(G.NumOfFaces(),    glm::mat4(0));

        // Initially, we compute Q matrix for each faces and it accumulates at each vertex.
        for (auto f : G.Faces()) {
            auto Q                 = UpdateQ(f);
            Qv[f->VertexIndex(0)] += Q;
            Qv[f->VertexIndex(1)] += Q;
            Qv[f->VertexIndex(2)] += Q;
            Kf[G.IndexOf(f)]       = Q;
        }

        pair_map.reserve(G.NumOfFaces() * 3);
        pairs.reserve(G.NumOfFaces() * 3 / 2);

        // Initially, we make pairs from all the contractable edges.
        for (auto e : G.Edges()) {
            if (! G.IsContractable(e)) continue;
            auto v1                            = e->From();
            auto v2                            = e->To();
            auto pair                          = MakePair(e, input.Positions[v1], input.Positions[v2], Qv[v1] + Qv[v2]);
            pair_map[G.IndexOf(e)]             = pairs.size();
            pair_map[G.IndexOf(e->TwinEdge())] = pairs.size();
            pairs.emplace_back(pair);
        }

        // Loop until the number of vertices is less than $simplification_ratio * initial_size$.
        while (G.NumOfVertices() > simplification_ratio * Qv.size()) {
            // Find the contractable pair with minimal cost.
            std::size_t min_idx = ~0;
            for (std::size_t i = 1; i < pairs.size(); ++i) {
                if (! pairs[i].edge) continue;
                if (!~min_idx || pairs[i].cost < pairs[min_idx].cost) {
                    if (G.IsContractable(pairs[i].edge)) min_idx = i;
                    else pairs[i].edge = nullptr;
                }
            }
            if (!~min_idx) break;

            // top:    the contractable pair with minimal cost
            // v1:     the reserved vertex
            // v2:     the removed vertex
            // result: the contract result
            // ring:   the edge ring of vertex v1
            ContractionPair & top    = pairs[min_idx];
            auto               v1     = top.edge->From();
            auto               v2     = top.edge->To();
            auto               result = G.Contract(top.edge);
            auto               ring   = G.Vertex(v1)->Ring();

            top.edge             = nullptr;            // The contraction has already been done, so the pair is no longer valid. Mark it as invalid.
            output.Positions[v1] = top.targetPosition; // Update the positions.

            // We do something to repair $pair_map$ and $pairs$ because some edges and vertices no longer exist.
            for (int i = 0; i < 2; ++i) {
                DCEL::EdgeIdx removed           = G.IndexOf(result.removed_edges[i].first);
                DCEL::EdgeIdx collapsed         = G.IndexOf(result.collapsed_edges[i].second);
                pairs[pair_map[removed]].edge   = result.collapsed_edges[i].first;
                pairs[pair_map[collapsed]].edge = nullptr;
                pair_map[collapsed]             = pair_map[G.IndexOf(result.collapsed_edges[i].first)];
            }

            // For the two wing vertices, each of them lose one incident face.
            // So, we update the Q matrix.
            Qv[result.removed_faces[0].first] -= Kf[G.IndexOf(result.removed_faces[0].second)];
            Qv[result.removed_faces[1].first] -= Kf[G.IndexOf(result.removed_faces[1].second)];

            // For the vertex v1, Q matrix should be recomputed.
            // And as the position of v1 changed, all the vertices which are on the ring of v1 should update their Q matrix as well.
            Qv[v1] = glm::mat4(0);
            glm::mat4 Qv1 = glm::mat4(0);
            for (auto e : ring) {
                // your code here:
                //     1. Compute the new Kp matrix for $e->Face()$.
                //     2. According to the difference between the old Kp (in $Kf$) and the new Kp (computed in step 1),
                //        update Q matrix of each vertex on the ring (update $Qv$).
                //     3. Update Q matrix of vertex v1 as well (update $Qv$).
                //     4. Update $Kf$.
                auto f=e->Face();
                auto new_Kp=UpdateQ(f);
                auto f_idx=G.IndexOf(f);
                auto old_Kp=Kf[f_idx]; 
                for(int j=0;j<3;j++)
                {
                    auto vidx=f->VertexIndex(j);
                    Qv[vidx]+=new_Kp-old_Kp;
                }//更新这个面上三个顶点的Q矩阵
                Qv1+=new_Kp;//更新v1的Q矩阵（变化量等于周围所有面的Kp变化量相加）
                Kf[f_idx]=new_Kp;//更新Kf（这个面的Kp矩阵）
            }
            Qv[v1]=Qv1;

            // Finally, as the Q matrix changed, we should update the relative $ContractionPair$ in $pairs$.
            // Any pair with the Q matrix of its endpoints changed, should be remade by $MakePair$.
            // your code here:
            for(auto v_neighbor:G.Vertex(v1)->Neighbors())//遍历v1周围的顶点，v_neighbor是索引
            {
                for(auto ee:G.Vertex(v_neighbor)->Ring())//遍历周围顶点的邻边
                {
                    auto e=ee->PrevEdge();//相邻顶点的邻边,接下来要处理这个边在pair里的情况
                    auto idx1=pair_map[G.IndexOf(e)];
                    if(G.IsContractable(e))
                    {
                        auto v_from=e->From();
                        auto v_to=e->To();
                        pairs[idx1]=MakePair(e,output.Positions[v_from],output.Positions[v_to],Qv[v_from]+Qv[v_to]);
                    }
                    if(!G.IsContractable(e))
                    {
                        pairs[idx1].edge=nullptr;
                    }                   
                }      
            }
        }

        // In the end, we check if the result mesh is watertight and manifold.
        if (! G.DebugWatertightManifold()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::SimplifyMesh(..): Result is not watertight manifold.");
        }

        auto exported = G.ExportMesh();
        output.Indices.swap(exported.Indices);
    }

    /******************* 4. Mesh Smoothing *****************/
    void SmoothMesh(Engine::SurfaceMesh const & input, Engine::SurfaceMesh & output, std::uint32_t numIterations, float lambda, bool useUniformWeight) {
        // Define function to compute cotangent value of the angle v1-vAngle-v2
        static constexpr auto GetCotangent {
            [] (glm::vec3 vAngle, glm::vec3 v1, glm::vec3 v2) -> float {
                // your code here:
                glm::vec3 edge_vector1=v1-vAngle;
                glm::vec3 edge_vector2=v2-vAngle;
                //return std::clamp(abs(glm::dot(edge_vector1,edge_vector2)/glm::length(glm::cross(edge_vector1,edge_vector2))),0.1f,10.0f);
                float denom = glm::length(glm::cross(edge_vector1, edge_vector2));
                float dedot = glm::dot(edge_vector1, edge_vector2);
                if (denom < 1e-8f) return 0.0f;
                if (dedot < 0.0f) dedot= -dedot;
                float cot = std::clamp(dedot / denom, 0.0f, 10.0f);
                return cot;
            }
        };

        DCEL G(input);
        if (! G.IsManifold()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::SmoothMesh(..): Non-manifold mesh.");
            return;
        }
        // We only allow watertight mesh.
        if (! G.IsWatertight()) {
            spdlog::warn("VCX::Labs::GeometryProcessing::SmoothMesh(..): Non-watertight mesh.");
            return;
        }

        Engine::SurfaceMesh prev_mesh;
        prev_mesh.Positions = input.Positions;float w;
        for (std::uint32_t iter = 0; iter < numIterations; ++iter) {
            Engine::SurfaceMesh curr_mesh = prev_mesh;
            for (std::size_t i = 0; i < input.Positions.size(); ++i) {
                // your code here: curr_mesh.Positions[i] = ...
                w=0;
                glm::vec3 wv_sum={0.0f,0.0f,0.0f};
                for(auto edge :G.Vertex(i)->Ring())
                {
                    auto v_idx=edge->From();
                    if(useUniformWeight) 
                    {
                        w+=1;wv_sum+=prev_mesh.Positions[v_idx];
                    }
                    else
                    {
                        auto vAngle=prev_mesh.Positions[edge->To()];
                        auto v2=prev_mesh.Positions[edge->PrevEdge()->From()];
                        auto cot1=GetCotangent(vAngle,prev_mesh.Positions[v_idx],v2);
                        vAngle=prev_mesh.Positions[edge->PrevEdge()->TwinEdge()->NextEdge()->To()];
                        auto cot2=GetCotangent(vAngle,prev_mesh.Positions[v_idx],v2);
                        w+=cot1;w+=cot2;
                        wv_sum+=prev_mesh.Positions[v_idx]*(cot1+cot2);
                    }
                }
                curr_mesh.Positions[i]=(1-lambda)*prev_mesh.Positions[i]+lambda*(wv_sum/w);
            }
            // Move curr_mesh to prev_mesh.
            prev_mesh.Swap(curr_mesh);
        }
        // Move prev_mesh to output.
        output.Swap(prev_mesh);
        // Copy indices from input.
        output.Indices = input.Indices;
    }

    /******************* 5. Marching Cubes *****************/
    glm::vec3 interpolate(const glm::vec3 & p1, const glm::vec3 & p2, float valp1, float valp2)
    {
        if(abs(valp1-valp2)<0.00001f)
            return p1;
        float mu=(0.0f-valp1)/(valp2-valp1);
        return p1+mu*(p2-p1);
    }
    glm::vec3 unit(int i)
    {
        if(i==0) return glm::vec3(1,0,0);
        if(i==1) return glm::vec3(0,1,0);
        return glm::vec3(0,0,1);
    }
    struct Edge_had_Vertex
    {
        glm::vec3 start;glm::vec3 end;int idx;
        Edge_had_Vertex(glm::vec3 s,glm::vec3 e,int i):start(s),end(e),idx(i){}
        bool operator==(const Edge_had_Vertex & other) const
        {
            return (start==other.start && end==other.end)||(start==other.end && end==other.start);
        }
    };

    void MarchingCubes(Engine::SurfaceMesh & output, const std::function<float(const glm::vec3 &)> & sdf, const glm::vec3 & grid_min, const float dx, const int n) {
        // your code here:
        std::vector<Edge_had_Vertex> edges;
        for(int z=0;z<n;z++)
        {
            for(int y=0;y<n;y++)
            {
                for(int x=0;x<n;x++)
                {
                    //设置当前立方体各个顶点的sdf正负并且标到8位数字v上便于查表
                    uint8_t v=0;
                    glm::vec3 base=grid_min+glm::vec3(x*dx,y*dx,z*dx);
                    for(int i=0;i<8;i++)
                    {
                        glm::vec3 vertex=base+glm::vec3((i&1)*dx,((i>>1)&1)*dx,((i>>2)&1)*dx);
                        if(sdf(vertex)<0.0f)
                        {
                            v|=(1<<i);
                        }
                    }
                    std::vector<int> idx_of_new_vertices(12,-1);//记录该立方体12条边上新生成的顶点在output.Positions中的索引
                    uint32_t edgeState=c_EdgeStateTable[v];
                    for(int j=0;j<12;j++)
                    {
                        if(edgeState&(1<<j))//如果该边上有交点
                        {
                            glm::vec3 start,end,new_vertex;
                            start=base + dx * (j & 1) * unit(((j >> 2) + 1) % 3) + dx * ((j >> 1) & 1) * unit(((j >> 2) + 2) % 3);
                            //end=base + dx * ((j & 1) ^ 1) * unit(((j >> 2) + 1) % 3) + dx * ((j >> 1) & 1) * unit(((j >> 2) + 2) % 3);//找到该边的起止点
                            end=start + dx * unit((j >> 2) % 3);
                            new_vertex=interpolate(start,end,sdf(start),sdf(end));
                            //int d[3]={0};

                            Edge_had_Vertex edge_check(start,end,-1);
                            auto it=std::find(edges.begin(),edges.end(),edge_check);
                            if(it!=edges.end())//如果该边已经处理过了
                            {
                                idx_of_new_vertices[j]=it->idx;
                            }
                            else
                            {
                                idx_of_new_vertices[j]=output.Positions.size();
                                edges.push_back(Edge_had_Vertex(start,end,idx_of_new_vertices[j]));
                                output.Positions.push_back(new_vertex);
                            }

                        }
                    }
                    for(int k=0;k<5;k++)
                    {
                        uint32_t e0 = c_EdgeOrdsTable[v][3*k], e1 = c_EdgeOrdsTable[v][3*k+1], e2 = c_EdgeOrdsTable[v][3*k+2];
                        if(e0==-1) break;
                        output.Indices.push_back(idx_of_new_vertices[e0]);
                        output.Indices.push_back(idx_of_new_vertices[e1]);  
                        output.Indices.push_back(idx_of_new_vertices[e2]);
                    }
                    
                }
            }
        }
    }
} // namespace VCX::Labs::GeometryProcessing
